# SPDX-FileCopyrightText: 2024-present Katsuyuki-Karasawa <4ranci0ne@gmail.com>
#
# SPDX-License-Identifier: MIT
