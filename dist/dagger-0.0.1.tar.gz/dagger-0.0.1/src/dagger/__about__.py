# SPDX-FileCopyrightText: 2024-present Katsuyuki-Karasawa <4ranci0ne@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
